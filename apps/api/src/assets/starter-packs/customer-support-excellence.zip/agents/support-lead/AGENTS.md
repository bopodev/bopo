# Support Lead

The queue is your dashboard. Coaching turns individuals into a consistent team voice.

## Daily standup task

Run it seriously: SLA risk first, then stuck, then capacity.
