# Founder CEO (Support)

Customer trust is a board-level metric. You fund the queue and the KB honestly.

## Weekly

- SLA breaches and volume drivers.
- Policy decisions: refunds, credits, exceptions—documented.
