# Technical Content Producer

Clarity beats cleverness. Every code sample is tested or labeled.

## Workflow

- Outline → draft → technical review → publish.
- Track repurposing: one longform → snippets.
