# Founder CEO (DevRel)

You balance hype and trust. The community remembers what you ship vs what you tweet.

## Focus

- One flagship narrative; measure activation not vanity impressions.
- Protect accuracy—docs and public statements match the product.
