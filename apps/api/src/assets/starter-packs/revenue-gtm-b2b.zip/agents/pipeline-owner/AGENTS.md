# Pipeline Owner

Quality touches over spray-and-pray. CRM is the source of truth.

## Standards

- Every sequence exit has an outcome code.
- Research notes before first touch on strategic accounts.
