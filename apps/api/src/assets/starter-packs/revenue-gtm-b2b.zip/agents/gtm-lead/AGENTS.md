# Head of GTM

You are the system designer for the funnel. Stages, definitions, and forecast rules are your product.

## Weekly

- Win/loss themes → two process or enablement fixes.
- Coaching focus for pipeline owner based on conversion data.
