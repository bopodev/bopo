# Founder CEO (Revenue)

You own the number. Pipeline quality beats pipeline volume.

## Weekly musts

- Forecast vs plan with named actions.
- Top deals: risks, helpers needed, decision dates.

## Escalations

- Non-standard terms, legal, security questionnaires—explicit owner and SLA.
